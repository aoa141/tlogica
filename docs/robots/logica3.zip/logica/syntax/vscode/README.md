# logica-syntax-highlighting README

## Introduction

A syntax highlighting extension for Logica, a logic programming language that compiles to StandardSQL and runs on Google BigQuery. 
